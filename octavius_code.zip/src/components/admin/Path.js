export const Path = 'http://localhost/octivius/src/components/admin/backend/';
//export const Path = 'https://developerssupport.com/cc/backend/';