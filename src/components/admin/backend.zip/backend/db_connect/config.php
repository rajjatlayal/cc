<?php
// $databaseHost = 'localhost';
// $databaseUsername = 'root';
// $databasePassword = '';
// $databaseName = 'cc_project';

$databaseHost = 'localhost';
$databaseName = 'iotairuh_cc_project';
$databaseUsername = 'iotairuh_cc_project';
$databasePassword = '';

$conn = mysqli_connect($databaseHost, $databaseUsername, $databasePassword, $databaseName); 
?>